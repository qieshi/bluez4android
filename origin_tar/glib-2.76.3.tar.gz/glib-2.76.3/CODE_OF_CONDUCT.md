Code of Conduct
===

GLib follows the GNOME Code of Conduct, which is documented here:
https://wiki.gnome.org/Foundation/CodeOfConduct
